
<div class="zq_h4_hero-form mb-40 mb-lg-0">
<form action="detail-form.php" method="POST">
    <input type="text" name="name" placeholder="Name*" required>
    <input type="email" name="email" placeholder="Email*" required>
    <input type="tel" name="phone" placeholder="Phone*" required>
    <textarea name="message" placeholder="Write a Message" required></textarea>
    <!--<input type="hidden" id="recaptchaToken" name="recaptchaToken">-->
    <!--<div class="g-recaptcha" data-sitekey="6LcrHfcpAAAAAN1UvB8-0ZjLJ0hkrpkPSi9zX4C7" data-callback="onRecaptchaSuccess">
    </div> -->

    <div class="text-center">
        <button name="submit" type="submit">Submit Now</button>
        <!--<div id="msgSubmit" class="h3 text-center hidden"></div>-->
        <!--<div class="clearfix"></div>-->
    </div>

</form>
</div>